using System;
using Xunit;

namespace ApplicationUnitTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
        }
    }
}