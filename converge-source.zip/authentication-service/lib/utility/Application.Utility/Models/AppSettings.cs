namespace Application.Utility.Models
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}