namespace Application.Utility.Models
{
    public class MessageObj
    {
        public MessageObj(string message)
        {
            Message = message;
        }

        public string Message { get; set; }
    }
}