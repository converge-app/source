namespace Application.Utility.ClientLibrary
{
    public class UserData
    {
        public string Id { get; set; }
        public string Email { get; set; }
    }
}