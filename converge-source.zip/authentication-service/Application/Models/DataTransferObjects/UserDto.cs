using System;

namespace Application.Models.DataTransferObjects
{
    public class UserDto
    {
        public string Email { get; set; }
        public string Id { get; set; }
    }
}