namespace Application.Models.DataTransferObjects
{
    public class UserRegisteredDto
    {
        public string Id { get; set; }
        public string Email { get; set; }
    }
}