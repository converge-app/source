#!/bin/bash

dotnet run --project /home/hermansen/git/converge/authentication-service/Application/Application.csproj
