﻿namespace Application.Utility.ClientLibrary.Collaboration
{
  public class BidData
  {
    public string Id { get; set; }
    public string ProjectId { get; set; }
    public string FreelancerId { get; set; }
    public string Message { get; set; }
    public decimal Amount { get; set; }
  }
}