﻿namespace Application.Utility.ClientLibrary.Collaboration
{
  public class TransferData
  {
    public string SenderId { get; set; }
    public string ReceiverId { get; set; }
    public long Amount { get; set; }
  }
}