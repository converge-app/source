#!/bin/bash

dotnet run --project /home/hermansen/git/converge/services/Chat-service/Application/Application.csproj
