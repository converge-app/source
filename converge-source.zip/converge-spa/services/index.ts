import {AuthenticationService} from './authentication.service';

export const services = {
    authentication: new AuthenticationService(),
}
