export interface INavBarLinkProps {
    className?: any;
}
