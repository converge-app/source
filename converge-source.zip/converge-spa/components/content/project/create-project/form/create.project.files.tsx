import {FunctionComponent} from 'react';

const CreateProjectFiles: FunctionComponent = () => {
    return <div></div>;
};

export default CreateProjectFiles;
