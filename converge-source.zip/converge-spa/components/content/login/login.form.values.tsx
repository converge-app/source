export interface IFormValues {
    email: string;
    password: string;
}
