export interface IFormValues {
    email: string;
}
