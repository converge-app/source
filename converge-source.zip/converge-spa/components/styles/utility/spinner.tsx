import { CircularProgress } from '@material-ui/core';

const Spinner = () => {
  return <CircularProgress></CircularProgress>;
};

export default Spinner;
