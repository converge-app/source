module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/styles/theme/theme.ts":
/*!******************************************!*\
  !*** ./components/styles/theme/theme.ts ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__);

const theme = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["createMuiTheme"])({
  palette: {
    primary: {
      main: '#13A8FE'
    },
    secondary: {
      main: '#ffffff'
    },
    error: {
      main: '#CF0060'
    },
    background: {
      default: '#262B32'
    },
    text: {
      primary: '#fff',
      secondary: '#9B9B9B'
    }
  },
  typography: {
    fontFamily: ['Montserrat', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'].join(','),
    fontWeightBold: 900,
    fontWeightMedium: 600,
    fontWeightRegular: 400,
    fontWeightLight: 200
  },
  overrides: {
    MuiPaper: {
      root: {
        backgroundColor: '#38414d'
      }
    }
  }
});
/* harmony default export */ __webpack_exports__["default"] = (theme);

/***/ }),

/***/ "./lib/constants/alert.constants.ts":
/*!******************************************!*\
  !*** ./lib/constants/alert.constants.ts ***!
  \******************************************/
/*! exports provided: alertConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "alertConstants", function() { return alertConstants; });
const alertConstants = {
  SUCCESS: 'ALERT_SUCCESS',
  ERROR: 'ALERT_ERROR',
  CLEAR: 'ALERT_CLEAR'
};

/***/ }),

/***/ "./lib/constants/bid.constants.ts":
/*!****************************************!*\
  !*** ./lib/constants/bid.constants.ts ***!
  \****************************************/
/*! exports provided: bidConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bidConstants", function() { return bidConstants; });
const bidConstants = {
  PLACE_BID_REQUEST: "BID_PLACE_REQUEST",
  PLACE_BID_SUCCESS: "BID_PLACE_SUCCESS",
  PLACE_BID_FAILURE: "BID_PLACE_FAILURE",
  GET_BY_PROJECT_REQUEST: "BID_GET_BY_PROJECT_REQUEST",
  GET_BY_PROJECT_SUCCESS: "BID_GET_BY_PROJECT_SUCCESS",
  GET_BY_PROJECT_FAILURE: "BID_GET_BY_PROJECT_FAILURE",
  CHOOSE_FREELANCER_REQUEST: "BID_CHOOSE_FREELANCER_REQUEST",
  CHOOSE_FREELANCER_SUCCESS: "BID_CHOOSE_FREELANCER_SUCCESS",
  CHOOSE_FREELANCER_FAILURE: "BID_CHOOSE_FREELANCER_FAILURE"
};

/***/ }),

/***/ "./lib/constants/collaboration.constants.ts":
/*!**************************************************!*\
  !*** ./lib/constants/collaboration.constants.ts ***!
  \**************************************************/
/*! exports provided: collaborationConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "collaborationConstants", function() { return collaborationConstants; });
const collaborationConstants = {
  GET_COLLABORATION_BY_PROJECT_REQUEST: 'COLLABORATION_GET_BY_PROJECT_REQUEST',
  GET_COLLABORATION_BY_PROJECT_SUCCESS: 'COLLABORATION_GET_BY_PROJECT_SUCCESS',
  GET_COLLABORATION_BY_PROJECT_FAILURE: 'COLLABORATION_GET_BY_PROJECT_FAILURE',
  COLLABORATION_CREATE_REQUEST: 'COLLABORATION_CREATE_REQUEST',
  COLLABORATION_CREATE_SUCCESS: 'COLLABORATION_CREATE_SUCCESS',
  COLLABORATION_CREATE_FAILURE: 'COLLABORATION_CREATE_FAILURE',
  COLLABORATION_FILES_SUBMIT_REQUEST: 'COLLABORATION_FILES_SUBMIT_REQUEST',
  COLLABORATION_FILES_SUBMIT_SUCCESS: 'COLLABORATION_FILES_SUBMIT_SUCCESS',
  COLLABORATION_FILES_SUBMIT_FAILURE: 'COLLABORATION_FILES_SUBMIT_FAILURE'
};

/***/ }),

/***/ "./lib/constants/contacts.constants.ts":
/*!*********************************************!*\
  !*** ./lib/constants/contacts.constants.ts ***!
  \*********************************************/
/*! exports provided: contactsConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "contactsConstants", function() { return contactsConstants; });
const contactsConstants = {
  GET_CONTACTS_REQUEST: "CONTACTS_GET_REQUEST",
  GET_CONTACTS_SUCCESS: "CONTACTS_GET_SUCCESS",
  GET_CONTACTS_FAILURE: "CONTACTS_GET_FAILURE",
  ADD_CONTACTS_REQUEST: "CONTACTS_ADD_REQUEST",
  ADD_CONTACTS_SUCCESS: "CONTACTS_ADD_SUCCESS",
  ADD_CONTACTS_FAILURE: "CONTACTS_ADD_FAILURE",
  SET_CURRENT_CONTACT: "CONTACTS_SET_CURRENT"
};

/***/ }),

/***/ "./lib/constants/message.constants.ts":
/*!********************************************!*\
  !*** ./lib/constants/message.constants.ts ***!
  \********************************************/
/*! exports provided: messageConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "messageConstants", function() { return messageConstants; });
const messageConstants = {
  GET_MESSAGES_REQUEST: "GET_MESSAGES_REQUEST",
  GET_MESSAGES_SUCCESS: "GET_MESSAGES_SUCCESS",
  GET_MESSAGES_FAILURE: "GET_MESSAGES_FAILURE",
  SEND_MESSAGES_REQUEST: "SEND_MESSAGES_REQUEST",
  SEND_MESSAGES_SUCCESS: "SEND_MESSAGES_SUCCESS",
  SEND_MESSAGES_FAILURE: "SEND_MESSAGES_FAILURE"
};

/***/ }),

/***/ "./lib/constants/payment.constants.ts":
/*!********************************************!*\
  !*** ./lib/constants/payment.constants.ts ***!
  \********************************************/
/*! exports provided: paymentConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "paymentConstants", function() { return paymentConstants; });
const paymentConstants = {
  CHECK_ACCOUNT_EXISTS_REQUEST: 'PAYMENT_CHECK_ACCOUNT_EXISTS_REQUEST',
  CHECK_ACCOUNT_EXISTS_SUCCESS: 'PAYMENT_CHECK_ACCOUNT_EXISTS_SUCCESS',
  CHECK_ACCOUNT_EXISTS_FAILURE: 'PAYMENT_CHECK_ACCOUNT_EXISTS_FAILURE'
};

/***/ }),

/***/ "./lib/constants/profile.constants.ts":
/*!********************************************!*\
  !*** ./lib/constants/profile.constants.ts ***!
  \********************************************/
/*! exports provided: profileConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "profileConstants", function() { return profileConstants; });
const profileConstants = {
  GET_BY_USER_REQUEST: 'PROFILE_GET_BY_USER_REQUEST',
  GET_BY_USER_NOT_FOUND: 'PROFILE_GET_BY_USER_NOT_FOUND',
  GET_BY_USER_SUCCESS: 'PROFILE_GET_BY_USER_SUCCESS',
  GET_BY_USER_FAILURE: 'PROFILE_GET_BY_USER_FAILURE',
  CREATE_PROFILE_REQUEST: 'PROFILE_CREATE_REQUEST',
  CREATE_PROFILE_SUCCESS: 'PROFILE_CREATE_SUCCESS',
  CREATE_PROFILE_FAILURE: 'PROFILE_CREATE_FAILURE',
  UPDATE_PROFILE_REQUEST: 'PROFILE_UPDATE_REQUEST',
  UPDATE_PROFILE_SUCCESS: 'PROFILE_UPDATE_SUCCESS',
  UPDATE_PROFILE_FAILURE: 'PROFILE_UPDATE_FAILURE'
};

/***/ }),

/***/ "./lib/constants/project.constants.ts":
/*!********************************************!*\
  !*** ./lib/constants/project.constants.ts ***!
  \********************************************/
/*! exports provided: projectConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "projectConstants", function() { return projectConstants; });
const projectConstants = {
  CREATE_PROJECT_REQUEST: 'PROJECT_CREATE_REQUEST',
  CREATE_PROJECT_SUCCESS: 'PROJECT_CREATE_SUCCESS',
  CREATE_PROJECT_FAILURE: 'PROJECT_CREATE_FAILURE',
  GET_PROJECTS_REQUEST: 'PROJECTS_GET_REQUEST',
  GET_PROJECTS_SUCCESS: 'PROJECTS_GET_SUCCESS',
  GET_PROJECTS_FAILURE: 'PROJECTS_GET_FAILURE',
  GET_PROJECT_REQUEST: 'PROJECT_GET_REQUEST',
  GET_PROJECT_SUCCESS: 'PROJECT_GET_SUCCESS',
  GET_PROJECT_FAILURE: 'PROJECT_GET_FAILURE',
  GET_OPEN_PROJECTS_REQUEST: 'OPEN_PROJECTS_GET_REQUEST',
  GET_OPEN_PROJECTS_SUCCESS: 'OPEN_PROJECTS_GET_SUCCESS',
  GET_OPEN_PROJECTS_FAILURE: 'OPEN_PROJECTS_GET_FAILURE',
  GET_MY_PROJECTS_REQUEST: 'PROJECTS_GET_MINE_REQUEST',
  GET_MY_PROJECTS_SUCCESS: 'PROJECTS_GET_MINE_SUCCESS',
  GET_MY_PROJECTS_FAILURE: 'PROJECTS_GET_MINE_FAILURE'
};

/***/ }),

/***/ "./lib/constants/submit.constants.ts":
/*!*******************************************!*\
  !*** ./lib/constants/submit.constants.ts ***!
  \*******************************************/
/*! exports provided: submitConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitConstants", function() { return submitConstants; });
const submitConstants = {
  SET_SUBMITTING: 'SUBMIT_SET',
  SHOW_MESSAGE_SUCCESS: 'SUBMIT_MESSAGE_SUCCESS',
  SHOW_MESSAGE_FAILURE: 'SUBMIT_MESSAGE_FAILURE',
  ALERT_CLEAR: 'SUBMIT_CLEAR',
  SUCCESS: 'SUCCESS',
  FAILURE: 'FAILURE'
};

/***/ }),

/***/ "./lib/constants/user.constants.ts":
/*!*****************************************!*\
  !*** ./lib/constants/user.constants.ts ***!
  \*****************************************/
/*! exports provided: userConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userConstants", function() { return userConstants; });
const userConstants = {
  LOGIN_REQUEST: 'USERS_LOGIN_REQUEST',
  LOGIN_SUCCESS: 'USERS_LOGIN_SUCCESS',
  LOGIN_FAILURE: 'USERS_LOGIN_FAILURE',
  LOGOUT: 'USERS_LOGOUT',
  SIGN_UP_REQUEST: 'USERS_SIGN_UP_REQUEST',
  SIGN_UP_SUCCESS: 'USERS_SIGN_UP_SUCCESS',
  SIGN_UP_FAILURE: 'USERS_SIGN_UP_FAILURE',
  GET_ALL_REQUEST: 'USERS_GET_ALL_REQUEST',
  GET_ALL_SUCCESS: 'USERS_GET_ALL_SUCCESS',
  GET_ALL_FAILURE: 'USERS_GET_ALL_FAILURE'
};

/***/ }),

/***/ "./lib/reducers/alert.reducer.ts":
/*!***************************************!*\
  !*** ./lib/reducers/alert.reducer.ts ***!
  \***************************************/
/*! exports provided: alert */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "alert", function() { return alert; });
/* harmony import */ var _constants_alert_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/alert.constants */ "./lib/constants/alert.constants.ts");

const alert = (state = {}, action) => {
  switch (action.type) {
    case _constants_alert_constants__WEBPACK_IMPORTED_MODULE_0__["alertConstants"].SUCCESS:
      return {
        type: 'alertSuccess',
        message: action.message
      };

    case _constants_alert_constants__WEBPACK_IMPORTED_MODULE_0__["alertConstants"].ERROR:
      return {
        type: 'alertDanger',
        message: action.message
      };

    case _constants_alert_constants__WEBPACK_IMPORTED_MODULE_0__["alertConstants"].CLEAR:
      return {};

    default:
      return state;
  }
};

/***/ }),

/***/ "./lib/reducers/authentication.reducer.ts":
/*!************************************************!*\
  !*** ./lib/reducers/authentication.reducer.ts ***!
  \************************************************/
/*! exports provided: authentication */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "authentication", function() { return authentication; });
/* harmony import */ var _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/user.constants */ "./lib/constants/user.constants.ts");

const authentication = (state = {}, action) => {
  switch (action.type) {
    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].LOGIN_REQUEST:
      return {
        loggingIn: true,
        user: action.user
      };

    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].LOGIN_SUCCESS:
      return {
        loggedIn: true,
        user: action.user
      };

    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].LOGIN_FAILURE:
      return {};

    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].LOGOUT:
      return {};

    default:
      return state;
  }
};

/***/ }),

/***/ "./lib/reducers/bidding.reducer.ts":
/*!*****************************************!*\
  !*** ./lib/reducers/bidding.reducer.ts ***!
  \*****************************************/
/*! exports provided: bidding */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bidding", function() { return bidding; });
/* harmony import */ var _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/bid.constants */ "./lib/constants/bid.constants.ts");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_1__);



const postBidRequest = (state = {}, action) => {
  switch (action.type) {
    case _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__["bidConstants"].PLACE_BID_REQUEST:
      return {
        postingBid: true,
        bid: action.bid
      };

    case _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__["bidConstants"].PLACE_BID_SUCCESS:
      return {
        postedBid: true,
        bid: action.bid
      };

    case _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__["bidConstants"].PLACE_BID_FAILURE:
      return {};

    default:
      return state;
  }
};

const getByProjectId = (state = {}, action) => {
  switch (action.type) {
    case _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__["bidConstants"].GET_BY_PROJECT_REQUEST:
      return {
        gettingBids: true,
        projectId: action.projectId
      };

    case _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__["bidConstants"].GET_BY_PROJECT_SUCCESS:
      return {
        gotBids: true,
        bids: action.bids
      };

    case _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__["bidConstants"].GET_BY_PROJECT_FAILURE:
      return {};

    default:
      return state;
  }
};

const chooseFreelancer = (state = {}, action) => {
  switch (action.type) {
    case _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__["bidConstants"].CHOOSE_FREELANCER_REQUEST:
      return {
        choosingFreelancer: true,
        bid: action.bid
      };

    case _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__["bidConstants"].CHOOSE_FREELANCER_SUCCESS:
      return {
        freelancerChosen: true
      };

    case _constants_bid_constants__WEBPACK_IMPORTED_MODULE_0__["bidConstants"].CHOOSE_FREELANCER_FAILURE:
      return {};

    default:
      return state;
  }
};

const bidding = Object(redux__WEBPACK_IMPORTED_MODULE_1__["combineReducers"])({
  postBidRequest,
  getByProjectId,
  chooseFreelancer
});

/***/ }),

/***/ "./lib/reducers/broker.reducer.ts":
/*!****************************************!*\
  !*** ./lib/reducers/broker.reducer.ts ***!
  \****************************************/
/*! exports provided: broker */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "broker", function() { return broker; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/collaboration.constants */ "./lib/constants/collaboration.constants.ts");


const InitializeInitialState = {
  initializing: false,
  initialized: false,
  result: null
};

const initialize = (state = InitializeInitialState, action) => {
  switch (action.type) {
    case _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__["collaborationConstants"].COLLABORATION_FILES_SUBMIT_REQUEST:
      return {
        initializing: true,
        result: action.result
      };

    case _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__["collaborationConstants"].COLLABORATION_FILES_SUBMIT_SUCCESS:
      return {
        initialized: true,
        result: action.result
      };

    case _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__["collaborationConstants"].COLLABORATION_FILES_SUBMIT_FAILURE:
      return InitializeInitialState;

    default:
      return state;
  }
};

const broker = Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  initialize
});

/***/ }),

/***/ "./lib/reducers/collaboration.reducer.ts":
/*!***********************************************!*\
  !*** ./lib/reducers/collaboration.reducer.ts ***!
  \***********************************************/
/*! exports provided: collaboration */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "collaboration", function() { return collaboration; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/collaboration.constants */ "./lib/constants/collaboration.constants.ts");



const getByProjectId = (state = {}, action) => {
  switch (action.type) {
    case _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__["collaborationConstants"].GET_COLLABORATION_BY_PROJECT_REQUEST:
      return {
        gettingCollaboration: true,
        projectId: action.projectId
      };

    case _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__["collaborationConstants"].GET_COLLABORATION_BY_PROJECT_SUCCESS:
      return {
        gotCollaboration: true,
        collaboration: action.collaboration
      };

    case _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__["collaborationConstants"].GET_COLLABORATION_BY_PROJECT_FAILURE:
      return {};

    default:
      return state;
  }
};

const createEvent = (state = {}, action) => {
  switch (action.type) {
    case _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__["collaborationConstants"].COLLABORATION_CREATE_REQUEST:
      return {
        creatingEvent: true,
        event: action.event
      };

    case _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__["collaborationConstants"].COLLABORATION_CREATE_SUCCESS:
      return {
        createdEvent: true,
        event: action.event
      };

    case _constants_collaboration_constants__WEBPACK_IMPORTED_MODULE_1__["collaborationConstants"].COLLABORATION_CREATE_FAILURE:
      return {};

    default:
      return state;
  }
};

const collaboration = Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  getByProjectId,
  createEvent
});

/***/ }),

/***/ "./lib/reducers/contacts.reducer.ts":
/*!******************************************!*\
  !*** ./lib/reducers/contacts.reducer.ts ***!
  \******************************************/
/*! exports provided: contacts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "contacts", function() { return contacts; });
/* harmony import */ var _constants_contacts_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/contacts.constants */ "./lib/constants/contacts.constants.ts");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_1__);



const getContacts = (state = {}, action) => {
  switch (action.type) {
    case _constants_contacts_constants__WEBPACK_IMPORTED_MODULE_0__["contactsConstants"].GET_CONTACTS_REQUEST:
      return {
        gettingContacts: true,
        userId: action.userId
      };

    case _constants_contacts_constants__WEBPACK_IMPORTED_MODULE_0__["contactsConstants"].GET_CONTACTS_SUCCESS:
      return {
        gotContacts: true,
        contacts: action.contacts
      };

    case _constants_contacts_constants__WEBPACK_IMPORTED_MODULE_0__["contactsConstants"].GET_CONTACTS_FAILURE:
      return {};

    default:
      return state;
  }
};

const addContact = (state = {}, action) => {
  switch (action.type) {
    case _constants_contacts_constants__WEBPACK_IMPORTED_MODULE_0__["contactsConstants"].ADD_CONTACTS_REQUEST:
      return {
        gettingContacts: true,
        userId: action.userId
      };

    case _constants_contacts_constants__WEBPACK_IMPORTED_MODULE_0__["contactsConstants"].ADD_CONTACTS_SUCCESS:
      return {
        gotContacts: true,
        contacts: action.contacts
      };

    case _constants_contacts_constants__WEBPACK_IMPORTED_MODULE_0__["contactsConstants"].ADD_CONTACTS_FAILURE:
      return {};

    default:
      return state;
  }
};

const setCurrentContact = (state = {}, action) => {
  switch (action.type) {
    case _constants_contacts_constants__WEBPACK_IMPORTED_MODULE_0__["contactsConstants"].SET_CURRENT_CONTACT:
      return {
        contactId: action.userId
      };

    default:
      return state;
  }
};

const contacts = Object(redux__WEBPACK_IMPORTED_MODULE_1__["combineReducers"])({
  getContacts,
  setCurrentContact,
  addContact
});

/***/ }),

/***/ "./lib/reducers/index.ts":
/*!*******************************!*\
  !*** ./lib/reducers/index.ts ***!
  \*******************************/
/*! exports provided: rootReducer, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rootReducer", function() { return rootReducer; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _alert_reducer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./alert.reducer */ "./lib/reducers/alert.reducer.ts");
/* harmony import */ var _authentication_reducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./authentication.reducer */ "./lib/reducers/authentication.reducer.ts");
/* harmony import */ var _bidding_reducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./bidding.reducer */ "./lib/reducers/bidding.reducer.ts");
/* harmony import */ var _broker_reducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./broker.reducer */ "./lib/reducers/broker.reducer.ts");
/* harmony import */ var _collaboration_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./collaboration.reducer */ "./lib/reducers/collaboration.reducer.ts");
/* harmony import */ var _contacts_reducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./contacts.reducer */ "./lib/reducers/contacts.reducer.ts");
/* harmony import */ var _message_reducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./message.reducer */ "./lib/reducers/message.reducer.ts");
/* harmony import */ var _payment_reducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./payment.reducer */ "./lib/reducers/payment.reducer.ts");
/* harmony import */ var _profile_reducer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./profile.reducer */ "./lib/reducers/profile.reducer.ts");
/* harmony import */ var _project_reducer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./project.reducer */ "./lib/reducers/project.reducer.ts");
/* harmony import */ var _sign_up_reducer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./sign-up.reducer */ "./lib/reducers/sign-up.reducer.ts");
/* harmony import */ var _submit_reducer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./submit.reducer */ "./lib/reducers/submit.reducer.ts");
/* harmony import */ var _user_reducer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./user.reducer */ "./lib/reducers/user.reducer.ts");














const rootReducer = Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  authentication: _authentication_reducer__WEBPACK_IMPORTED_MODULE_2__["authentication"],
  signUp: _sign_up_reducer__WEBPACK_IMPORTED_MODULE_11__["signUp"],
  users: _user_reducer__WEBPACK_IMPORTED_MODULE_13__["users"],
  alert: _alert_reducer__WEBPACK_IMPORTED_MODULE_1__["alert"],
  project: _project_reducer__WEBPACK_IMPORTED_MODULE_10__["project"],
  bidding: _bidding_reducer__WEBPACK_IMPORTED_MODULE_3__["bidding"],
  collaboration: _collaboration_reducer__WEBPACK_IMPORTED_MODULE_5__["collaboration"],
  contacts: _contacts_reducer__WEBPACK_IMPORTED_MODULE_6__["contacts"],
  message: _message_reducer__WEBPACK_IMPORTED_MODULE_7__["message"],
  profile: _profile_reducer__WEBPACK_IMPORTED_MODULE_9__["profile"],
  submitting: _submit_reducer__WEBPACK_IMPORTED_MODULE_12__["submitting"],
  payment: _payment_reducer__WEBPACK_IMPORTED_MODULE_8__["payment"],
  broker: _broker_reducer__WEBPACK_IMPORTED_MODULE_4__["broker"]
});
/* harmony default export */ __webpack_exports__["default"] = (rootReducer);

/***/ }),

/***/ "./lib/reducers/message.reducer.ts":
/*!*****************************************!*\
  !*** ./lib/reducers/message.reducer.ts ***!
  \*****************************************/
/*! exports provided: message */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "message", function() { return message; });
/* harmony import */ var _constants_message_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/message.constants */ "./lib/constants/message.constants.ts");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_1__);



const getMessages = (state = {}, action) => {
  switch (action.type) {
    case _constants_message_constants__WEBPACK_IMPORTED_MODULE_0__["messageConstants"].GET_MESSAGES_REQUEST:
      return {
        sendMsg: true,
        msg: action.msg
      };

    case _constants_message_constants__WEBPACK_IMPORTED_MODULE_0__["messageConstants"].GET_MESSAGES_SUCCESS:
      return {
        sendMsg: true,
        msg: action.msg
      };

    case _constants_message_constants__WEBPACK_IMPORTED_MODULE_0__["messageConstants"].GET_MESSAGES_FAILURE:
      return {};

    default:
      return state;
  }
};

const sendMessage = (state = {}, action) => {
  switch (action.type) {
    case _constants_message_constants__WEBPACK_IMPORTED_MODULE_0__["messageConstants"].SEND_MESSAGES_REQUEST:
      return {
        sendingMessage: true,
        message: action.message
      };

    case _constants_message_constants__WEBPACK_IMPORTED_MODULE_0__["messageConstants"].SEND_MESSAGES_SUCCESS:
      return {
        sentMessage: true,
        message: action.message
      };

    case _constants_message_constants__WEBPACK_IMPORTED_MODULE_0__["messageConstants"].SEND_MESSAGES_FAILURE:
      return {};

    default:
      return state;
  }
};

const message = Object(redux__WEBPACK_IMPORTED_MODULE_1__["combineReducers"])({
  getMessages,
  sendMessage
});

/***/ }),

/***/ "./lib/reducers/payment.reducer.ts":
/*!*****************************************!*\
  !*** ./lib/reducers/payment.reducer.ts ***!
  \*****************************************/
/*! exports provided: payment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "payment", function() { return payment; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_payment_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/payment.constants */ "./lib/constants/payment.constants.ts");


const accountExistsInitialState = {
  gettingAccount: false,
  gotAccount: false
};

const accountExists = (state = accountExistsInitialState, action) => {
  switch (action.type) {
    case _constants_payment_constants__WEBPACK_IMPORTED_MODULE_1__["paymentConstants"].CHECK_ACCOUNT_EXISTS_REQUEST:
      return {
        gettingAccount: true,
        userId: action.userId
      };

    case _constants_payment_constants__WEBPACK_IMPORTED_MODULE_1__["paymentConstants"].CHECK_ACCOUNT_EXISTS_SUCCESS:
      return {
        gotAccount: true,
        exists: action.exists
      };

    case _constants_payment_constants__WEBPACK_IMPORTED_MODULE_1__["paymentConstants"].CHECK_ACCOUNT_EXISTS_FAILURE:
      return accountExistsInitialState;

    default:
      return state;
  }
};

const payment = Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  accountExists
});

/***/ }),

/***/ "./lib/reducers/profile.reducer.ts":
/*!*****************************************!*\
  !*** ./lib/reducers/profile.reducer.ts ***!
  \*****************************************/
/*! exports provided: profile */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "profile", function() { return profile; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/profile.constants */ "./lib/constants/profile.constants.ts");



const getByUserId = (state = {}, action) => {
  switch (action.type) {
    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].GET_BY_USER_REQUEST:
      return {
        gettingProfile: true,
        userId: action.userId
      };

    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].GET_BY_USER_SUCCESS:
      return {
        gotProfile: true,
        profile: action.profile
      };

    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].GET_BY_USER_NOT_FOUND:
      return {
        gotProfile: false,
        status: "Profile was not found or doesn't exist"
      };

    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].GET_BY_USER_FAILURE:
      return {};

    default:
      return state;
  }
};

const createProfile = (state = {}, action) => {
  switch (action.type) {
    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].CREATE_PROFILE_REQUEST:
      return {
        creatingProfile: true,
        profile: action.profile
      };

    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].CREATE_PROFILE_SUCCESS:
      return {
        createdProject: true,
        profile: action.profile
      };

    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].CREATE_PROFILE_FAILURE:
      return {};

    default:
      return state;
  }
};

const updateProfile = (state = {}, action) => {
  switch (action.type) {
    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].UPDATE_PROFILE_REQUEST:
      return {
        creatingProfile: true,
        profile: action.profile
      };

    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].UPDATE_PROFILE_SUCCESS:
      return {
        createdProject: true,
        profile: action.profile
      };

    case _constants_profile_constants__WEBPACK_IMPORTED_MODULE_1__["profileConstants"].UPDATE_PROFILE_FAILURE:
      return {};

    default:
      return state;
  }
};

const profile = Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  getByUserId,
  createProfile,
  updateProfile
});

/***/ }),

/***/ "./lib/reducers/project.reducer.ts":
/*!*****************************************!*\
  !*** ./lib/reducers/project.reducer.ts ***!
  \*****************************************/
/*! exports provided: project */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "project", function() { return project; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/project.constants */ "./lib/constants/project.constants.ts");



const createProjectRequest = (state = {}, action) => {
  switch (action.type) {
    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].CREATE_PROJECT_REQUEST:
      return {
        creatingProject: true,
        project: action.project
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].CREATE_PROJECT_SUCCESS:
      return {
        createdProject: true,
        project: action.project
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].CREATE_PROJECT_FAILURE:
      return {};

    default:
      return state;
  }
};

const getProjects = (state = {}, action) => {
  switch (action.type) {
    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_PROJECTS_REQUEST:
      return {
        gettingProjects: true
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_PROJECTS_SUCCESS:
      return {
        gotProjects: true,
        projects: action.projects
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_PROJECTS_FAILURE:
      return {};

    default:
      return state;
  }
};

const getProject = (state = {}, action) => {
  switch (action.type) {
    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_PROJECT_REQUEST:
      return {
        gettingProject: true,
        projectId: action.projectId
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_PROJECT_SUCCESS:
      return {
        gotProjects: true,
        project: action.project
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_PROJECT_FAILURE:
      return {};

    default:
      return state;
  }
};

const getOpenProjects = (state = {}, action) => {
  switch (action.type) {
    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_OPEN_PROJECTS_REQUEST:
      return {
        gettingOpenProjects: true
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_OPEN_PROJECTS_SUCCESS:
      return {
        gotOpenProjects: true,
        projects: action.projects
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_OPEN_PROJECTS_FAILURE:
      return {};

    default:
      return state;
  }
};

const getMyProjects = (state = {}, action) => {
  switch (action.type) {
    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_MY_PROJECTS_REQUEST:
      return {
        gettingMyProjects: true,
        userId: action.userId
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_MY_PROJECTS_SUCCESS:
      return {
        gotMyProjects: true,
        projects: action.projects
      };

    case _constants_project_constants__WEBPACK_IMPORTED_MODULE_1__["projectConstants"].GET_MY_PROJECTS_FAILURE:
      return {};

    default:
      return state;
  }
};

const project = Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  createProjectRequest,
  getProjects,
  getProject,
  getOpenProjects,
  getMyProjects
});

/***/ }),

/***/ "./lib/reducers/sign-up.reducer.ts":
/*!*****************************************!*\
  !*** ./lib/reducers/sign-up.reducer.ts ***!
  \*****************************************/
/*! exports provided: signUp */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signUp", function() { return signUp; });
/* harmony import */ var _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/user.constants */ "./lib/constants/user.constants.ts");

const signUp = (state = {}, action) => {
  switch (action.type) {
    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].SIGN_UP_REQUEST:
      return {
        signingUp: true,
        user: action.user
      };

    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].SIGN_UP_SUCCESS:
      return {
        signedUp: true,
        user: action.user
      };

    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].SIGN_UP_FAILURE:
      return {};

    default:
      return state;
  }
};

/***/ }),

/***/ "./lib/reducers/submit.reducer.ts":
/*!****************************************!*\
  !*** ./lib/reducers/submit.reducer.ts ***!
  \****************************************/
/*! exports provided: submitting */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "submitting", function() { return submitting; });
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-properties */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptors */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptors.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptor */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-symbols */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var _constants_submit_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../constants/submit.constants */ "./lib/constants/submit.constants.ts");








function ownKeys(object, enumerableOnly) { var keys = _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5___default()(object); if (_babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default.a) { var symbols = _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default()(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default()(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_6__["default"])(target, key, source[key]); }); } else if (_babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default.a) { _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1___default()(target, _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default()(source)); } else { ownKeys(Object(source)).forEach(function (key) { _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, key, _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default()(source, key)); }); } } return target; }


const submitting = (state = {}, action) => {
  switch (action.type) {
    case _constants_submit_constants__WEBPACK_IMPORTED_MODULE_7__["submitConstants"].SET_SUBMITTING:
      return _objectSpread({}, state, {
        submitting: action.submitting,
        active: true,
        query: action.isQuery
      });

    case _constants_submit_constants__WEBPACK_IMPORTED_MODULE_7__["submitConstants"].SHOW_MESSAGE_SUCCESS:
      return {
        submitting: false,
        active: true,
        message: action.message,
        type: _constants_submit_constants__WEBPACK_IMPORTED_MODULE_7__["submitConstants"].SUCCESS
      };

    case _constants_submit_constants__WEBPACK_IMPORTED_MODULE_7__["submitConstants"].SHOW_MESSAGE_FAILURE:
      return {
        submitting: false,
        active: true,
        message: action.message,
        type: _constants_submit_constants__WEBPACK_IMPORTED_MODULE_7__["submitConstants"].FAILURE
      };

    case _constants_submit_constants__WEBPACK_IMPORTED_MODULE_7__["submitConstants"].ALERT_CLEAR:
      return {
        submitting: false,
        active: false,
        message: '',
        type: ''
      };

    default:
      return state;
  }
};

/***/ }),

/***/ "./lib/reducers/user.reducer.ts":
/*!**************************************!*\
  !*** ./lib/reducers/user.reducer.ts ***!
  \**************************************/
/*! exports provided: users */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "users", function() { return users; });
/* harmony import */ var _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/user.constants */ "./lib/constants/user.constants.ts");

const users = (state = {}, action) => {
  switch (action.type) {
    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].GET_ALL_REQUEST:
      return {
        loading: true
      };

    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].GET_ALL_SUCCESS:
      return {
        items: action.users
      };

    case _constants_user_constants__WEBPACK_IMPORTED_MODULE_0__["userConstants"].GET_ALL_FAILURE:
      return {
        error: action.error
      };

    default:
      return state;
  }
};

/***/ }),

/***/ "./lib/store/store.ts":
/*!****************************!*\
  !*** ./lib/store/store.ts ***!
  \****************************/
/*! exports provided: initializeStore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeStore", function() { return initializeStore; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-devtools-extension */ "redux-devtools-extension");
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! redux-logger */ "redux-logger");
/* harmony import */ var redux_logger__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_logger__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! redux-thunk */ "redux-thunk");
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_thunk__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _reducers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../reducers */ "./lib/reducers/index.ts");





const initialState = {
  authentication: {},
  signUp: {},
  users: {},
  alert: {},
  project: {
    createProjectRequest: {},
    getProjects: {},
    getProject: {}
  }
};
const initializeStore = (preloadedState = initialState) => {
  const loggerMiddleware = Object(redux_logger__WEBPACK_IMPORTED_MODULE_2__["createLogger"])();
  preloadedState = preloadedState;
  return Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(_reducers__WEBPACK_IMPORTED_MODULE_4__["default"], Object(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_1__["composeWithDevTools"])(Object(redux__WEBPACK_IMPORTED_MODULE_0__["applyMiddleware"])(redux_thunk__WEBPACK_IMPORTED_MODULE_3___default.a, loggerMiddleware)));
};

/***/ }),

/***/ "./lib/store/with-redux-store.tsx":
/*!****************************************!*\
  !*** ./lib/store/with-redux-store.tsx ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-properties */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptors */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptors.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-descriptor */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/get-own-property-symbols */ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");
/* harmony import */ var _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/defineProperty */ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./store */ "./lib/store/store.ts");








var _jsxFileName = "/home/hermansen/Desktop/source/converge-spa/lib/store/with-redux-store.tsx";
var __jsx = react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement;

function ownKeys(object, enumerableOnly) { var keys = _babel_runtime_corejs2_core_js_object_keys__WEBPACK_IMPORTED_MODULE_5___default()(object); if (_babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default.a) { var symbols = _babel_runtime_corejs2_core_js_object_get_own_property_symbols__WEBPACK_IMPORTED_MODULE_4___default()(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default()(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_7__["default"])(target, key, source[key]); }); } else if (_babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default.a) { _babel_runtime_corejs2_core_js_object_define_properties__WEBPACK_IMPORTED_MODULE_1___default()(target, _babel_runtime_corejs2_core_js_object_get_own_property_descriptors__WEBPACK_IMPORTED_MODULE_2___default()(source)); } else { ownKeys(Object(source)).forEach(function (key) { _babel_runtime_corejs2_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(target, key, _babel_runtime_corejs2_core_js_object_get_own_property_descriptor__WEBPACK_IMPORTED_MODULE_3___default()(source, key)); }); } } return target; }



const isServer = true;
const __NEXT_REDUX_STORE__ = '__NEXT_REDUX_STORE__';

const getOrCreateStore = (initialState = null) => {
  if (isServer) {
    return Object(_store__WEBPACK_IMPORTED_MODULE_9__["initializeStore"])(initialState);
  } // @ts-ignore


  if (!window[__NEXT_REDUX_STORE__]) {
    // @ts-ignore
    window[__NEXT_REDUX_STORE__] = Object(_store__WEBPACK_IMPORTED_MODULE_9__["initializeStore"])(initialState);
  } // @ts-ignore


  return window[__NEXT_REDUX_STORE__];
};

/* harmony default export */ __webpack_exports__["default"] = (App => {
  var _temp;

  return _temp = class AppWithRedux extends react__WEBPACK_IMPORTED_MODULE_8___default.a.Component {
    static async getInitialProps(appContext) {
      const reduxStore = getOrCreateStore();
      appContext.ctx.reduxStore = reduxStore;
      let appProps = {};

      if (typeof App.getInitialProps === 'function') {
        appProps = await App.getInitialProps(appContext);
      }

      return _objectSpread({}, appProps, {
        initialReduxState: reduxStore.getState()
      });
    }

    constructor(props) {
      super(props);

      Object(_babel_runtime_corejs2_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_7__["default"])(this, "reduxStore", void 0);

      this.reduxStore = getOrCreateStore(props.initialReduxState);
    }

    render() {
      return __jsx(App, Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_6__["default"])({}, this.props, {
        reduxStore: this.reduxStore,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 48
        },
        __self: this
      }));
    }

  }, _temp;
});

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/assign.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/assign.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/assign */ "core-js/library/fn/object/assign");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/define-properties.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/define-properties */ "core-js/library/fn/object/define-properties");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/define-property */ "core-js/library/fn/object/define-property");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptor.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/get-own-property-descriptor */ "core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptors.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-descriptors.js ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/get-own-property-descriptors */ "core-js/library/fn/object/get-own-property-descriptors");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/get-own-property-symbols.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/get-own-property-symbols */ "core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js":
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/object/keys.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/object/keys */ "core-js/library/fn/object/keys");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/core-js/promise.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/core-js/promise.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! core-js/library/fn/promise */ "core-js/library/fn/promise");

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/asyncToGenerator.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/asyncToGenerator.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _Promise = __webpack_require__(/*! ../core-js/promise */ "./node_modules/@babel/runtime-corejs2/core-js/promise.js");

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    _Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new _Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

module.exports = _asyncToGenerator;

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/defineProperty.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _defineProperty; });
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");
/* harmony import */ var _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0__);

function _defineProperty(obj, key, value) {
  if (key in obj) {
    _core_js_object_define_property__WEBPACK_IMPORTED_MODULE_0___default()(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js":
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _extends; });
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core-js/object/assign */ "./node_modules/@babel/runtime-corejs2/core-js/object/assign.js");
/* harmony import */ var _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_core_js_object_assign__WEBPACK_IMPORTED_MODULE_0__);

function _extends() {
  _extends = _core_js_object_assign__WEBPACK_IMPORTED_MODULE_0___default.a || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/extends.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/extends.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _Object$assign = __webpack_require__(/*! ../core-js/object/assign */ "./node_modules/@babel/runtime-corejs2/core-js/object/assign.js");

function _extends() {
  module.exports = _extends = _Object$assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "./node_modules/@babel/runtime-corejs2/helpers/interopRequireDefault.js":
/*!******************************************************************************!*\
  !*** ./node_modules/@babel/runtime-corejs2/helpers/interopRequireDefault.js ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/next/app.js":
/*!**********************************!*\
  !*** ./node_modules/next/app.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/pages/_app */ "./node_modules/next/dist/pages/_app.js")


/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/utils.js":
/*!*********************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/utils.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _Object$keys = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/keys */ "./node_modules/@babel/runtime-corejs2/core-js/object/keys.js");

var _Object$defineProperty = __webpack_require__(/*! @babel/runtime-corejs2/core-js/object/define-property */ "./node_modules/@babel/runtime-corejs2/core-js/object/define-property.js");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

const url_1 = __webpack_require__(/*! url */ "url");
/**
 * Utils
 */


function execOnce(fn) {
  let used = false;
  let result = null;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn.apply(this, args);
    }

    return result;
  };
}

exports.execOnce = execOnce;

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

exports.getLocationOrigin = getLocationOrigin;

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

exports.getURL = getURL;

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

exports.getDisplayName = getDisplayName;

function isResSent(res) {
  return res.finished || res.headersSent;
}

exports.isResSent = isResSent;

async function loadGetInitialProps(App, ctx) {
  if (true) {
    if (App.prototype && App.prototype.getInitialProps) {
      const message = `"${getDisplayName(App)}.getInitialProps()" is defined as an instance method - visit https://err.sh/zeit/next.js/get-initial-props-as-an-instance-method for more information.`;
      throw new Error(message);
    }
  } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (true) {
    if (_Object$keys(props).length === 0 && !ctx.ctx) {
      console.warn(`${getDisplayName(App)} returned an empty object from \`getInitialProps\`. This de-optimizes and prevents automatic static optimization. https://err.sh/zeit/next.js/empty-object-getInitialProps`);
    }
  }

  return props;
}

exports.loadGetInitialProps = loadGetInitialProps;
exports.urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];

function formatWithValidation(url, options) {
  if (true) {
    if (url !== null && typeof url === 'object') {
      _Object$keys(url).forEach(key => {
        if (exports.urlObjectKeys.indexOf(key) === -1) {
          console.warn(`Unknown key passed via urlObject into url.format: ${key}`);
        }
      });
    }
  }

  return url_1.format(url, options);
}

exports.formatWithValidation = formatWithValidation;
exports.SUPPORTS_PERFORMANCE = typeof performance !== 'undefined';
exports.SUPPORTS_PERFORMANCE_USER_TIMING = exports.SUPPORTS_PERFORMANCE && typeof performance.mark === 'function' && typeof performance.measure === 'function';

/***/ }),

/***/ "./node_modules/next/dist/pages/_app.js":
/*!**********************************************!*\
  !*** ./node_modules/next/dist/pages/_app.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime-corejs2/helpers/interopRequireDefault */ "./node_modules/@babel/runtime-corejs2/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.Container = Container;
exports.createUrl = createUrl;
exports.default = void 0;

var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime-corejs2/helpers/extends */ "./node_modules/@babel/runtime-corejs2/helpers/extends.js"));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime-corejs2/helpers/asyncToGenerator */ "./node_modules/@babel/runtime-corejs2/helpers/asyncToGenerator.js"));

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _utils = __webpack_require__(/*! ../next-server/lib/utils */ "./node_modules/next/dist/next-server/lib/utils.js");

exports.AppInitialProps = _utils.AppInitialProps;
/**
* `App` component is used for initialize of pages. It allows for overwriting and full control of the `page` initialization.
* This allows for keeping state between navigation, custom error handling, injecting additional data.
*/

function appGetInitialProps(_x) {
  return _appGetInitialProps.apply(this, arguments);
}

function _appGetInitialProps() {
  _appGetInitialProps = (0, _asyncToGenerator2.default)(function* (_ref) {
    var {
      Component,
      ctx
    } = _ref;
    var pageProps = yield (0, _utils.loadGetInitialProps)(Component, ctx);
    return {
      pageProps
    };
  });
  return _appGetInitialProps.apply(this, arguments);
}

class App extends _react.default.Component {
  // Kept here for backwards compatibility.
  // When someone ended App they could call `super.componentDidCatch`.
  // @deprecated This method is no longer needed. Errors are caught at the top level
  componentDidCatch(error, _errorInfo) {
    throw error;
  }

  render() {
    var {
      router,
      Component,
      pageProps
    } = this.props;
    var url = createUrl(router);
    return _react.default.createElement(Component, (0, _extends2.default)({}, pageProps, {
      url: url
    }));
  }

}

exports.default = App;
App.origGetInitialProps = appGetInitialProps;
App.getInitialProps = appGetInitialProps;
var warnContainer;
var warnUrl;

if (true) {
  warnContainer = (0, _utils.execOnce)(() => {
    console.warn("Warning: the `Container` in `_app` has been deprecated and should be removed. https://err.sh/zeit/next.js/app-container-deprecated");
  });
  warnUrl = (0, _utils.execOnce)(() => {
    console.error("Warning: the 'url' property is deprecated. https://err.sh/zeit/next.js/url-deprecated");
  });
} // @deprecated noop for now until removal


function Container(p) {
  if (true) warnContainer();
  return p.children;
}

function createUrl(router) {
  // This is to make sure we don't references the router object at call time
  var {
    pathname,
    asPath,
    query
  } = router;
  return {
    get query() {
      if (true) warnUrl();
      return query;
    },

    get pathname() {
      if (true) warnUrl();
      return pathname;
    },

    get asPath() {
      if (true) warnUrl();
      return asPath;
    },

    back: () => {
      if (true) warnUrl();
      router.back();
    },
    push: (url, as) => {
      if (true) warnUrl();
      return router.push(url, as);
    },
    pushTo: (href, as) => {
      if (true) warnUrl();
      var pushRoute = as ? href : '';
      var pushUrl = as || href;
      return router.push(pushRoute, pushUrl);
    },
    replace: (url, as) => {
      if (true) warnUrl();
      return router.replace(url, as);
    },
    replaceTo: (href, as) => {
      if (true) warnUrl();
      var replaceRoute = as ? href : '';
      var replaceUrl = as || href;
      return router.replace(replaceRoute, replaceUrl);
    }
  };
}

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime-corejs2/helpers/esm/extends */ "./node_modules/@babel/runtime-corejs2/helpers/esm/extends.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_styles_ThemeProvider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/styles/ThemeProvider */ "@material-ui/styles/ThemeProvider");
/* harmony import */ var _material_ui_styles_ThemeProvider__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_styles_ThemeProvider__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/app */ "./node_modules/next/app.js");
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_app__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_styles_theme_theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/styles/theme/theme */ "./components/styles/theme/theme.ts");
/* harmony import */ var _lib_store_with_redux_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../lib/store/with-redux-store */ "./lib/store/with-redux-store.tsx");

var _jsxFileName = "/home/hermansen/Desktop/source/converge-spa/pages/_app.tsx";
var __jsx = react__WEBPACK_IMPORTED_MODULE_5___default.a.createElement;









class RootApp extends next_app__WEBPACK_IMPORTED_MODULE_3___default.a {
  componentDidMount() {
    const jssStyles = document.querySelector('#jss-server-side');

    if (jssStyles && jssStyles.parentNode) {
      jssStyles.parentNode.removeChild(jssStyles);
    }
  }

  render() {
    // @ts-ignore
    const {
      Component,
      pageProps,
      reduxStore
    } = this.props;
    return __jsx(react__WEBPACK_IMPORTED_MODULE_5___default.a.Fragment, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 23
      },
      __self: this
    }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_4___default.a, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 24
      },
      __self: this
    }, __jsx("title", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 25
      },
      __self: this
    }, "Converge"), __jsx("script", {
      src: "https://js.stripe.com/v3/",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 27
      },
      __self: this
    })), __jsx(_material_ui_styles_ThemeProvider__WEBPACK_IMPORTED_MODULE_2___default.a, {
      theme: _components_styles_theme_theme__WEBPACK_IMPORTED_MODULE_7__["default"],
      __source: {
        fileName: _jsxFileName,
        lineNumber: 29
      },
      __self: this
    }, __jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["CssBaseline"], {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 30
      },
      __self: this
    }), __jsx(react_redux__WEBPACK_IMPORTED_MODULE_6__["Provider"], {
      store: reduxStore,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 31
      },
      __self: this
    }, __jsx(Component, Object(_babel_runtime_corejs2_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, pageProps, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32
      },
      __self: this
    })))));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Object(_lib_store_with_redux_store__WEBPACK_IMPORTED_MODULE_8__["default"])(RootApp));

/***/ }),

/***/ 0:
/*!*****************************************!*\
  !*** multi private-next-pages/_app.tsx ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! private-next-pages/_app.tsx */"./pages/_app.tsx");


/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "@material-ui/styles/ThemeProvider":
/*!****************************************************!*\
  !*** external "@material-ui/styles/ThemeProvider" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/styles/ThemeProvider");

/***/ }),

/***/ "core-js/library/fn/object/assign":
/*!***************************************************!*\
  !*** external "core-js/library/fn/object/assign" ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/assign");

/***/ }),

/***/ "core-js/library/fn/object/define-properties":
/*!**************************************************************!*\
  !*** external "core-js/library/fn/object/define-properties" ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-properties");

/***/ }),

/***/ "core-js/library/fn/object/define-property":
/*!************************************************************!*\
  !*** external "core-js/library/fn/object/define-property" ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/define-property");

/***/ }),

/***/ "core-js/library/fn/object/get-own-property-descriptor":
/*!************************************************************************!*\
  !*** external "core-js/library/fn/object/get-own-property-descriptor" ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptor");

/***/ }),

/***/ "core-js/library/fn/object/get-own-property-descriptors":
/*!*************************************************************************!*\
  !*** external "core-js/library/fn/object/get-own-property-descriptors" ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-descriptors");

/***/ }),

/***/ "core-js/library/fn/object/get-own-property-symbols":
/*!*********************************************************************!*\
  !*** external "core-js/library/fn/object/get-own-property-symbols" ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/get-own-property-symbols");

/***/ }),

/***/ "core-js/library/fn/object/keys":
/*!*************************************************!*\
  !*** external "core-js/library/fn/object/keys" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/object/keys");

/***/ }),

/***/ "core-js/library/fn/promise":
/*!*********************************************!*\
  !*** external "core-js/library/fn/promise" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("core-js/library/fn/promise");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "redux":
/*!************************!*\
  !*** external "redux" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux");

/***/ }),

/***/ "redux-devtools-extension":
/*!*******************************************!*\
  !*** external "redux-devtools-extension" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-devtools-extension");

/***/ }),

/***/ "redux-logger":
/*!*******************************!*\
  !*** external "redux-logger" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-logger");

/***/ }),

/***/ "redux-thunk":
/*!******************************!*\
  !*** external "redux-thunk" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-thunk");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("url");

/***/ })

/******/ });
//# sourceMappingURL=_app.js.map