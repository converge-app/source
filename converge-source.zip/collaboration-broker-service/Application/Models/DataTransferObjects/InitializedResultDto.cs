﻿namespace Application.Models.DataTransferObjects
{
  public class InitializedResultDto
  {
    public string Id { get; set; }
    public string ProjectId { get; set; }
    public string FreelancerId { get; set; }
    public string State { get; set; }
  }
}