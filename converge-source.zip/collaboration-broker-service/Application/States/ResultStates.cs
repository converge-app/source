namespace Application.States
{
    public static class ResultStates
    {
        public static string FilesUploaded => "files-uploaded";
        public static string PaymentSubmittet => "payment-submitted";
        public static string Done => "project-done";

    }
}