#!/bin/bash

dotnet run --project /home/hermansen/git/converge/services/broker-service/Application/Application.csproj
