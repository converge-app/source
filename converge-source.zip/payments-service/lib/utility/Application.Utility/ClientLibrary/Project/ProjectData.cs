namespace Application.Utility.ClientLibrary.Project
{
    public class ProjectData
    {
        public string Id { get; set; }
        public string OwnerId { get; set; }
        public string FreelancerId { get; set; }
        public ProjectContentData ProjectContent { get; set; }
    }
}