#!/bin/bash

dotnet run --project /home/hermansen/git/converge/services/payment-service/Application/Application.csproj
