namespace Application.Models.DataTransferObjects
{
  public class PaymentIntentCreatedDto
  {
    public string ClientSecret { get; set; }
  }
}