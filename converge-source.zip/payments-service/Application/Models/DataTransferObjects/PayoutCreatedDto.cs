namespace Application.Models.DataTransferObjects
{
  public class PayoutCreatedDto
  {
    public string PayoutId { get; set; }
  }
}